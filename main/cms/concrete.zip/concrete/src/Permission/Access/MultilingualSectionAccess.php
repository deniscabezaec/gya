<?php
namespace Concrete\Core\Permission\Access;

defined('C5_EXECUTE') or die("Access Denied.");
class MultilingualSectionAccess extends PageAccess
{
}
