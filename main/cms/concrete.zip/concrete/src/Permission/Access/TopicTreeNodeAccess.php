<?php
namespace Concrete\Core\Permission\Access;

class TopicTreeNodeAccess extends TreeNodeAccess
{
}
