<?php
namespace Concrete\Core\Permission\Access;

class UserAccess extends Access
{
}
