<?php
namespace Concrete\Core\Permission\Access;

class AdminAccess extends Access
{
}
