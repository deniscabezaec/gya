<?php
namespace Concrete\Core\Permission\Access;

class FileAccess extends Access
{
}
