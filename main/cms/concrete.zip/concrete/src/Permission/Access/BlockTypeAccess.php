<?php
namespace Concrete\Core\Permission\Access;

class BlockTypeAccess extends Access
{
}
