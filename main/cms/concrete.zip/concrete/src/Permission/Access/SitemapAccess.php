<?php
namespace Concrete\Core\Permission\Access;

class SitemapAccess extends Access
{
}
