<?php
namespace Concrete\Core\Permission\Access\ListItem;

class MarketplaceNewsflowListItem extends ListItem
{
}
