<?php
namespace Concrete\Core\Permission\Access\ListItem;

class AdminListItem extends ListItem
{
}
