<?php
namespace Concrete\Core\Permission\Access\ListItem;

class CalendarListItem extends ListItem
{
}
