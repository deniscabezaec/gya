<?php
namespace Concrete\Core\Permission\Access\ListItem;

class BlockListItem extends ListItem
{
}
