<?php
namespace Concrete\Core\Permission\Access\ListItem;

class TreeNodeListItem extends ListItem
{
}
