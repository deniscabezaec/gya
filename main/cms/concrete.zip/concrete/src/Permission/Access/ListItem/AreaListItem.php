<?php
namespace Concrete\Core\Permission\Access\ListItem;

class AreaListItem extends ListItem
{
}
