<?php
namespace Concrete\Core\Permission\Access\ListItem;

class PageListItem extends ListItem
{
}
