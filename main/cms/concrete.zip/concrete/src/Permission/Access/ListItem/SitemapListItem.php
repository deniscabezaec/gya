<?php
namespace Concrete\Core\Permission\Access\ListItem;

class SitemapListItem extends ListItem
{
}
