<?php
namespace Concrete\Core\Permission\Access;

class PageTypeAccess extends Access
{
}
