<?php
namespace Concrete\Core\Permission\Access;

class SinglePageAccess extends PageAccess
{
}
