<?php
namespace Concrete\Core\Permission\Access;

class BlockAccess extends Access
{
}
