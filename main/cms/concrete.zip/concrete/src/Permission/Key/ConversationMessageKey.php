<?php
namespace Concrete\Core\Permission\Key;

class ConversationMessageKey extends Key
{
}
