<?php
namespace Concrete\Core\Permission\Key;

class StackKey extends PageKey
{
}
