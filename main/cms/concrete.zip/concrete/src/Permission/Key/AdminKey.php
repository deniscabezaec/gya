<?php
namespace Concrete\Core\Permission\Key;

class AdminKey extends Key
{
}
