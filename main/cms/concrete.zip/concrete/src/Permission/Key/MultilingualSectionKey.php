<?php
namespace Concrete\Core\Permission\Key;

defined('C5_EXECUTE') or die("Access Denied.");
class MultilingualSectionKey extends PageKey
{
}
