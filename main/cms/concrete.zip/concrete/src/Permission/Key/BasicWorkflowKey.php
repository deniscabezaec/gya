<?php
namespace Concrete\Core\Permission\Key;

class BasicWorkflowKey extends WorkflowKey
{
}
