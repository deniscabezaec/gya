<?php
namespace Concrete\Core\Permission\Key;

class GroupTreeNodeKey extends TreeNodeKey
{
}
