<?php
namespace Concrete\Core\Permission\Key;

class CalendarKey extends Key
{
}
