<?php
namespace Concrete\Core\Permission\Key;

/**
 * We need this class in place because upgrades from older versions die early
 * before upgrade can be complete without it.
 * @deprecated
 */
class TopicCategoryTreeNodeKey extends TreeNodeKey
{
}
