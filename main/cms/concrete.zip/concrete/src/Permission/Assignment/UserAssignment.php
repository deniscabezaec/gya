<?php
namespace Concrete\Core\Permission\Assignment;

class UserAssignment extends Assignment
{
}
