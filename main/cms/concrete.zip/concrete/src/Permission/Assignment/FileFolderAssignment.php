<?php
namespace Concrete\Core\Permission\Assignment;

use Concrete\Core\Permission\Access\Access as PermissionAccess;
use Concrete\Core\File\Set\Set;
use Database;

class FileFolderAssignment extends TreeNodeAssignment
{
}
