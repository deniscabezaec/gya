<?php
namespace Concrete\Core\Permission\Assignment;

class CategoryTreeNodeAssignment extends TreeNodeAssignment
{
}
