<?php
namespace Concrete\Core\Permission\Assignment;

class MarketplaceNewsflowAssignment extends Assignment
{
}
