<?php
namespace Concrete\Core\Permission\Assignment;

class BlockTypeAssignment extends Assignment
{
}
