<?php
namespace Concrete\Core\Permission\Assignment;

defined('C5_EXECUTE') or die("Access Denied.");
class MultilingualSectionAssignment extends PageAssignment
{
}
