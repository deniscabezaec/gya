<?php
namespace Concrete\Core\Permission\Response;

class SinglePageResponse extends PageResponse
{
}
