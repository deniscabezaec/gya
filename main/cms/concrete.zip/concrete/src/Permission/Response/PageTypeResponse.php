<?php
namespace Concrete\Core\Permission\Response;

class PageTypeResponse extends Response
{
}
