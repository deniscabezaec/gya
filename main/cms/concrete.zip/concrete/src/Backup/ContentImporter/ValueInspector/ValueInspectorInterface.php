<?php
namespace Concrete\Core\Backup\ContentImporter\ValueInspector;

interface ValueInspectorInterface
{
    public function inspect($content);
}
